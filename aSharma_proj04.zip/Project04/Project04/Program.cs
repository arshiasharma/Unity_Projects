﻿//https://stackoverflow.com/questions/1181419/verifying-that-a-string-contains-only-letters-in-c-sharp
//reference used for checking is a string only has letters

//https://docs.microsoft.com/en-us/dotnet/api/system.collections.generic.list-1.indexof?view=netframework-4.8
//IndexOf reference 

using System; //header files - import libraries
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace Project04
{
    class Program //start to build pass program 
    {
        static void Main(string[] args)
        {
            //outputting the current list 
            Console.WriteLine("Student Records: ");
            List<Student> record = new List<Student>();
            record = DeserializeListFromXML();

            foreach (Student student in record)
            {
                Console.WriteLine(student.StudentToString());
            }

            //expression for the while loop
            bool keepRunning = true;

            //Keeps the loop running until the user wants to exit 
            while (keepRunning)
            {
                Console.WriteLine();
                Console.WriteLine("1.Delete from file \n2.Add to file\n3.List all student \n4.View specific student \n5.Quit");
                Console.WriteLine();
                Console.Write("Enter a number: ");
                string choice = Console.ReadLine();
                Console.WriteLine();
                
                //Deleting from the List 
                if (choice == "1")
                {
                    foreach (Student student in record)
                    {
                        int ind = record.IndexOf(student) + 1;
                        Console.WriteLine(ind +  "." + " " + student.GetName());

                    }

                    Console.Write("Enter the number of the Student to be deleted: ");
                    string resp = Console.ReadLine();
                    int i = Int32.Parse(resp);
                   
                    record.RemoveAt(i-1);
                    SerializeListToXML(record);
                }

                //Adding to the List 
                if (choice == "2")
                {
                    Student s = new Student(Name(), Age().ToString(), Cap().ToString());
                    record.Add(s);

                }

                //Listing all Student Records 
                if(choice == "3")
                {
                    foreach (Student student in record)
                    {
                        Console.WriteLine(student.StudentToString());
                    }
                }

                //Selecting a specific Student 
                if(choice == "4")
                {
                    foreach (Student student in record)
                    {
                        int ind = record.IndexOf(student) + 1;
                        Console.WriteLine(ind + "." + " " + student.GetName());

                    }

                    Console.WriteLine();
                    Console.Write("Enter the number of the Student you'd like to view:  ");
             
                    string resp = Console.ReadLine();
                    int i = Int32.Parse(resp);
                    
                    foreach(Student student in record)
                    {
                        if(record.IndexOf(student) == i-1)
                        {
                            Console.WriteLine(student.StudentToString());
                        }
                    }
                }

                //Exiting the program 
                if(choice == "5")
                {
                    SerializeListToXML(record);
                    break;
                }
            }

            Console.ReadLine(); //break point, it stops here
        }

        /// <summary> This functions asks for the user's name </summary>
        /// <return> Returns the string. </return>
        static string Name()
        {
            string name;

            Console.Write("What is the student's name: ");
            name = Console.ReadLine();

            foreach (char c in name)
            {
                if (!Char.IsLetter(c))
                {
                    if ((c == '-') || (c == ' '))
                    {
                        break;
                    }
                    Console.WriteLine("Not a valid name, only letters, please try again");
                    name = Name();
                    break;
                }

            }
            return name;

        }
        /// <summary> This functions asks for the user's ages and checks if the input is an integer </summary>
        /// <return> Returns the age as an int </return>
        static int Age()
        {
            int age;

            Console.Write("What is student's age: ");
            string responseA = Console.ReadLine();
            if (int.TryParse(responseA, out age) == true)
            { //returns true or false 

            }
            else if (int.TryParse(responseA, out age) == false)
            {
                Console.WriteLine("Not a number, please try again");
                age = Age();
            }
            return age;
        }
        /// <summary> This functions asks the users is Captain America is the best Avenger and checks if the input is a boolean </summary>
        /// <return> Returns the answer as a boolean </return>
        static bool Cap()
        {
            bool cap;

            Console.Write("Captain America is the best Avenger, true/false: ");
            string resp = Console.ReadLine();
            if (bool.TryParse(resp, out cap))
            {

            }

            else
            {
                Console.WriteLine("please type in true or false");
                cap = Cap();
            }
            return cap;
        }
    
        ///<summary> This function serializes the list of objects to a file, used from in class example </summary>
        ///<return> nothing </return>
        public static void SerializeListToXML(List<Student> record)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Student>));
            TextWriter textWriter = new StreamWriter(@"student.xml");
            serializer.Serialize(textWriter, record);
            textWriter.Close();
        }

        ///<summary> This function deserializes the list of objects from a file, used from in class example </summary>
        ///<return> Returns the list of Students </return>
        public static List<Student> DeserializeListFromXML()
        {
            XmlSerializer deserializer = new XmlSerializer(typeof(List<Student>));
            TextReader textReader = new StreamReader(@"student.xml");
            List<Student> record = (List<Student>)deserializer.Deserialize(textReader);
            textReader.Close();
            return record;
        }
    
    }

    [Serializable()]

    ///<summary> Class of Students </summary>
    public class Student
    {
        public string Name { get; set; }
        public string Age { get; set; }
        public string Cap { get; set; }

        //default constructor
        public Student()
        {
            Name = "";
            Age = "";
            Cap = "";
        }

        //constructor
        public Student(string name,  string age, string cap)
        {
            this.Name = name;
            this.Age = age;
            this.Cap = cap;
        }

        /// <summary> Get name method </summary>
        /// <returns>Returns the name of the student </returns>
        public string GetName()
        {
            return Name;
        }

        /// <summary>Student to String method</summary>
        /// <returns>Returns a string of the member variable (info of the Student) </returns>
        public string StudentToString()
        {
            string answer = "\nName: " + Name + "\nAge: " + Age + "\nCaptain America is the best Avenger: " + Cap;
            return answer;
        }
    }
}
