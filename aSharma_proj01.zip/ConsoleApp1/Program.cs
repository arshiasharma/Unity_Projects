﻿class Program{ static void Main(){}}
