﻿//https://stackoverflow.com/questions/1181419/verifying-that-a-string-contains-only-letters-in-c-sharp
//reference used for checking is a string only has letters

using System; //header files - import libraries
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Project03
{
    class Program //start to build pass program 
    {
        static void Main(string[] args)
        {
            //expression for the while loop
            bool keepRunning = true;
            while (keepRunning)
            {
                string name = Name();
                int age = Age();
                bool cap = Cap();

                Console.WriteLine();
                Console.WriteLine("Name is: " + name);
                Console.WriteLine("Age is: " + age);
                Console.WriteLine("Captain America is the best Avenger: " + cap);
          

                Console.Write("Do you want to quit, yes/no: ");
                string choice = Console.ReadLine();

                switch (choice.ToLower())
                {
                    case "yes":
                    case "y":
                        keepRunning = false;
                        break;
                    case "no":
                    case "n":
                        break;
                    default:
                        break;

                }

            }

            Console.ReadLine(); //break point, it stops here
        }

        /// <summary> This functions asks for the user's name </summary>
        /// <return> Returns the string. </return>
        static string Name()
        {
            string name = "";
           
                Console.Write("What is your name: ");
                name = Console.ReadLine();

                foreach (char c in name)
                {
                    if (!Char.IsLetter(c))
                    { 
                        if((c == '-') || (c == ' '))
                        {
                            break;
                        }
                       Console.WriteLine("Not a valid name, only letters, please try again");
                       name = Name();
                       break;
                    }
                    
                }
            return name;

        }
        /// <summary> This functions asks for the user's ages and checks if the input is an integer </summary>
        /// <return> Returns the age as an int </return>
        static int Age()
        {
           int age = 0;
        
                Console.Write("What is your age: ");
                string responseA = Console.ReadLine();
                if (int.TryParse(responseA, out age) == true)
                { //returns true or false 
                 
                }
                else if (int.TryParse(responseA, out age) == false)
                {
                    Console.WriteLine("Not a number, please try again");
                    age = Age();  
                }
            return age;
        }
        /// <summary> This functions asks the users is Captain America is the best Avenger and checks if the input is a boolean </summary>
        /// <return> Returns the answer as a boolean </return>
        static bool Cap()
        {
            bool cap;

                Console.Write("Captain America is the best Avenger, true/false: ");
                string resp = Console.ReadLine();
                if (bool.TryParse(resp, out cap))
                {
                    
                }
                
                else
                {
                    Console.WriteLine("please type in true or false");
                    cap = Cap();
                }
            return cap;
        }
    }
}
