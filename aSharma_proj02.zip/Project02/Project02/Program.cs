﻿//Found int.Parse(Console.ReadLine()); (line 21, 23) at https://stackoverflow.com/questions/24443827/reading-an-integer-from-user-input

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project02
{
    class Program
    {
        static void Main(string[] args)
        {
            //initializing the two variables 
            int x;
            int y;
         
            //User input for the two integers 
            Console.Write("Enter first integer: ");
            x = int.Parse(Console.ReadLine()); 
            Console.Write("Enter secind integer: ");
            y = int.Parse(Console.ReadLine());
            Console.WriteLine();


            //calling the function in the main method 
            Console.WriteLine("Sum: " + Sum(x,y));
            Console.WriteLine("Difference: " + Difference(x, y));
            Console.WriteLine("Product: " + Product(x, y));
            Console.WriteLine("Quotient: " + Quotient(x, y));
            Console.WriteLine("Remainder: " + Remainder(x, y));

            //Read() so the user can see the answers they want and hit enter when ready to exit the program
            Console.Read();
        }
      
        /// <summary> This functions adds two integers to get its sum </summary>
        /// <param name="a"> The first value.param>
        /// <param name="b"> The second value.param>
        /// <return> Returns the sum. </return>
        static int Sum(int a, int b)
        {
            return (a + b);
        }
        /// <summary> This functions subtracts two integers to get its difference </summary>
        /// <param name="a"> The first value.param>
        /// <param name="b"> The second value.param>
        /// <return> Returns the difference </return>
        static int Difference(int a, int b)
        {
            return (a - b);
        }
        /// <summary> This functions multiply two integers to get its product </summary>
        /// <param name="a"> The first value.param>
        /// <param name="b"> The second value.param>
        /// <return> Returns the product </return>
        static int Product(int a, int b)
        {
            return (a * b);
        }
        /// <summary> This functions divides two integers to get its quotient </summary>
        /// <param name="a"> The first value.param>
        /// <param name="b"> The second value.param>
        /// <return> Returns the quotient. </return>
        static int Quotient(int a, int b)
        {
            return (a / b);
        }
        /// <summary> This functions divides two integers to get its remainder </summary>
        /// <param name="a"> The first value.param>
        /// <param name="b"> The second value.param>
        /// <return> Returns the remainder. </return>
        static int Remainder(int a, int b)
        {
            return (a % b);
        }

    }
}
