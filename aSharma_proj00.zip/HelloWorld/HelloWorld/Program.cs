﻿using System; //librarys (packages) access to systems stuff, you can get rid of this 
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld //you can get rid of this and it will be fine - Project 01, whole line and brackets 
{
    class Program //you have to have a class program 
    {
        static void Main(string[] args) //must have this (method and functions are the same)
        //void doesnt mean you dont need a return statement 
        //get rid of string [] args in Project 01, dont need parameters for this 
        {
            Console.WriteLine("hello world");
            Console.ReadLine(); //input from the variable, waits for users to hit enter
            //Console = accessing the Console class - want to access that method 
        }
    }
}
